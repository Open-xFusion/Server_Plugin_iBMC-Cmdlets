# xFusion iBMC Cmdlets

## Description

xFusion iBMC cmdlets provide powershell Cmdlets to manage iBMC using Redfish API.  
These cmdlets contains the most commonly used features such as: information query, RAID configuration, OS deploy, firmware upgrade.  

## Supported Device

xFusion Blade Server:        RH1288 V3, RH2288 V3, RH2288H V3, 1288H V5, 2288H V5, 2288 V5, 2488H V5, 1288H V6, 2288H V6  
xFusion Rack Server:         CH121 V3, CH242 V3  
xFusion High-density Server: XH622 V3, XH321 V5  

## Requirements

- PowerShell 5.0+

- [.Net Framework 4.5](http://www.microsoft.com/en-us/download/details.aspx?id=30653)

- [WMF 5.0](https://www.microsoft.com/en-us/download/details.aspx?id=50395)

## Install
- Local installation

  1、Decompress the xFusion-iBMC-Cmdlets v1.3.7.zip software packages to obtaion the xFusion-iBMC-Cmdlets folder  
  2、Copy the xFusion-iBMC-Cmdlets folder to the PowerShell installation directory  
  3、Run the following command to install xFusion-iBMC-Cmdlets:  
  
  ```powershell
  Import-Module -Name xFusion-iBMC-Cmdlets -Force
  ```

## Usage

This is a sample for get user accounts:

```powershell

PS C:\> $credential = Get-Credential
PS C:\> $session = Connect-iBMC -Address 192.168.1.1 -Credential $credential -TrustCert
PS C:\> $Users = Get-iBMCUser -Session $session
PS C:\> $Users

Host     : 192.168.1.1
Id       : 2
Name     : User Account
UserName : Administrator
RoleId   : Administrator
Locked   : False
Enabled  : True
Oem      : @{xFusion=}

Host     : 192.168.1.1
Id       : 3
Name     : User Account
UserName : root
RoleId   : Administrator
Locked   : True
Enabled  : True
Oem      : @{xFusion=}

```

To get all available cmdlets provided by xFusion-iBMC-Cmdlets

```
PS C:\> Get-Command -Module xFusion-iBMC-Cmdlets
```


To get help for a specified cmdlet:

```
PS C:\> get-help Connect-iBMC -Full
```